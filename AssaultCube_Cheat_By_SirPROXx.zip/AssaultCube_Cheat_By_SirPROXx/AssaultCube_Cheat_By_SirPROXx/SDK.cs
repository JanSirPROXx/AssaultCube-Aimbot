﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssaultCube_Cheat_By_SirPROXx
{
    public class SDK
    {

       




    }
    public class Enemy
    {
        public int Health { get; set; }

        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }

        public float Distance { get; set; }
    }
    public class Local
    {
        public int Health { get; set; }

        public float ViewX { get; set; }
        public float ViewY { get; set; }

        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }
    }
}
