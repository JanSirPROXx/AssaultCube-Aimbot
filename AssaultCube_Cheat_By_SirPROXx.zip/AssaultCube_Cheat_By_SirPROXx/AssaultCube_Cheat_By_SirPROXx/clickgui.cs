﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Memory;

namespace AssaultCube_Cheat_By_SirPROXx
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Für Memorylibary
        Mem m = new Mem();
        #region offsets

        //Base
        string PlayerBase = "ac_client.exe+0x109B74";
        String EntityList = "ac_client.exe+0x110D90";
        //Offsets
        string Health = ",0xF8";
        string X = ",0x4";
        string Y = ",0x8";
        string Z = ",0xC";
        string XView = ",0x40";
        string YView = ",0x44";

        #endregion

        [DllImport("user32.dll")]
        static extern short GetAsyncKeyState(Keys vKey);




        private void Form1_Load(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
            m.OpenProcess("ac_client");
            Thread AB = new Thread(Aimbot) { IsBackground = true };
            //AB.Start();
            Aimbot_bw.RunWorkerAsync();
        }

        Local GetLocal()
        {
            var alocal = new Local
            {
                X = m.ReadFloat(PlayerBase + X),
                Y = m.ReadFloat(PlayerBase + Y),
                Z = m.ReadFloat(PlayerBase + Z),
                ViewX = m.ReadFloat(PlayerBase + XView),
                ViewY = m.ReadFloat(PlayerBase + YView),
                Health = m.ReadInt(PlayerBase + Health),

            };
            return alocal;
        }
        float GetDistance(Local local, Enemy enemy)
        {
            float dist = (float)Math.Sqrt(Math.Pow(enemy.X - local.X, 2) + Math.Pow(enemy.Y - local.Y, 2) + Math.Pow(enemy.Z - local.Z, 2));
            return dist;
        }

        List<Enemy> GetEnemys(Local local)
        {
            var aenemys = new List<Enemy>();

            for (int i = 0; i < 20; i++) //Go 20 time through
            {
                var entitylist_i = EntityList + ",0x" + (i * 0x4).ToString("X");
                var aenemy = new Enemy()
                {
                    X = m.ReadFloat(entitylist_i + X),
                    Y = m.ReadFloat(entitylist_i + Y),
                    Z = m.ReadFloat(entitylist_i + Z),
                    Health = m.ReadInt(entitylist_i + Health)
                    
                    
                };
                aenemy.Distance = GetDistance(local, aenemy);

                if (aenemy.Health > 0 || aenemy.Health < 100)
                {
                    aenemys.Add(aenemy);
                }


            }

            return aenemys;
        }
        
        List<Enemy> GetNearestEnemys()
        {
            var LocalPlayer = GetLocal();
            var EntityPlayer = GetEnemys(LocalPlayer);
            EntityPlayer = EntityPlayer.OrderBy(o => o.Distance).ToList();


            return EntityPlayer;
        }

        private void Aim(Local Player, Enemy Enemy) //Aimbot Methode (Aim's on the nearest Enemy)
        {

            float deltaX = Enemy.X - Player.X;
            float deltaY = Enemy.Y - Player.Y;
            float deltaZ = Enemy.Z - Player.Z;

            float viewX = (float)(Math.Atan2(deltaY, deltaX) * 180 / Math.PI) + 90;
            double distance = Math.Sqrt(deltaX * deltaX + deltaY * deltaY);

            float viewY = (float)(Math.Atan2(deltaZ, distance) * 180 / Math.PI);

            m.WriteMemory(PlayerBase + XView, "float", viewX.ToString());
            m.WriteMemory(PlayerBase + YView, "float", viewY.ToString());

        }
        private void Aimbot()
        {
            while (true)
            {
                List<Enemy> Enemys = GetNearestEnemys();
                Enemy E1 = Enemys[0];
                Enemy E2 = Enemys[1];
                Enemy E3 = Enemys[2];
                Enemy E4 = Enemys[3];

                textBox1.Text = E1.Health.ToString();
                textBox2.Text = E2.Distance.ToString();
                textBox3.Text = E3.Distance.ToString();
                textBox4.Text = E4.Distance.ToString();
                Thread.Sleep(100);
            }
           
        }

        private void Aimbot_bw_DoWork(object sender, DoWorkEventArgs e)
        {
            while (true)
            {
                if (GetAsyncKeyState(Keys.X) < 0)
                {
                    var LocalPlayer = GetLocal();
                    var EntityPlayer = GetEnemys(LocalPlayer);
                    EntityPlayer = EntityPlayer.OrderBy(o => o.Distance).ToList();

                    if (EntityPlayer.Count != 0)
                    {
                        Aim(LocalPlayer, EntityPlayer[0]);
                    }

                    textBox1.Text = LocalPlayer.Health.ToString();
                }

                /*
                List<Enemy> Enemys = GetNearestEnemys();
                Enemy E1 = Enemys[0];
                Enemy E2 = Enemys[1];
                Enemy E3 = Enemys[2];
                Enemy E4 = Enemys[3];

                textBox1.Text = E1.Distance.ToString();
                textBox2.Text = E2.Distance.ToString();
                textBox3.Text = E3.Distance.ToString();
                textBox4.Text = E4.Distance.ToString();
                Thread.Sleep(100);
                */
            }
        }
    }
}
